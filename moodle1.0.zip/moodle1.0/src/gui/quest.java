/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import javax.swing.JRadioButton;

/**
 *
 * @author Rishabh
 */
public class quest {
    public Connection con;

    public Statement st;

    public ResultSet rs;
    private List<JRadioButton> correctButtons;
    public quest(){
        
    }
    
}
